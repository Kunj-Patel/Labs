To get the tests working:

 (1) Add main.cpp and Lab2Tests.hpp to your project containing DynamicStack.hpp/cpp and CircularQueue.hpp/cpp (make sure you don't have another main() function in your code; if you do, remove it or comment it out).
     
     (Right click on project in Dev-C++ -> Add to Project)
     
 (2) Run the program in Dev-C++